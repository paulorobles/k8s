For build efficiency, the src was not included in this release.
The full source code can be viewed at
https://github.com/kubernetes/federation/tree/85c06145286da663755b140efa2b65f793cce9ec
